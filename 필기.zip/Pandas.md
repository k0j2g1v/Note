<h1>Pandas</h1>
pandas는 python data분석의 핵심 module(package)

데이터분석

1. EDA(탐색적 데이터 분석) : 예) 엑셀을 통한 테이터 분석
   python언어로 pandas 를 이용하여 EDA 수행
2. 통계젹 데이터 분석 : 통계적쪽 이론을 이용한 분석
3. 머신러닝 : 기존데이터를 이용해서 프로그램을 학습   <-- 딥러닝
   이 학습된 결과를 이용해 예측

pandas는 고유한 자료구조를 2개 사용함
Series : numpy의 1차원 배열과 상당히 유사함
              동일한 데이터 타입의 복수개의 요소로 구성, 순서가 존재함
DataFrame : Table형식으로 구성된 
                       자료구조 2차원 배열과 상당히 유사
                       데이터베이스 테이블과 상당히 유사 
                       칼럼만 동일 타입이면 된다

````
import numpy as np
import pandas as pd
````

numpy 와 pandas를 사용하기위해 import해준다



````
arr = np.array([-1,10,50,99],dtype=np.float64)
print(arr)
````

numpy array 를  실수 타입으로 표기

````
s = pd.Series([-1,10,50,99],dtype=np.float64)
display(s) # 테이블 형태로 출력  
print(s.values) # numpy 1차원 array로 리턴
	=> [-1. 10. 50. 99.]
print(s.index)
	=> RangeIndex(start=0, stop=4, step=1)
print(s.dtype)
	=> float64
````

인덱스값 변경

````
s = pd.Series([-1,10,50,99], index =["c","a","k","tt"])
display(s)
print(s['a']) #다른 형식의 인덱스를 사용할 수 있다.
print(s[1])   #기존형태인 숫자 인덱스를 사용할 수 있다
print(s[1:3]) #일반적인 slicing 사용이 가능하다
print(s['c':'k']) #slicing기능 출력에 k포함
print(s.sum()) # 모든 요소의 합을 출력
````

공장 문제

````
A 공장의 2019-01-01부터 10일간 제품 생산량을 Series에
저장 - 단, 생산량의 평균은 50이고 표준편차는 5인
정규분포에서 생산량을 랜덤하게 결정

B 공장의 2019-01-01부터 10일간 제품 생산량을 Series에
저장 - 단, 생산량의 평균은 70이고 표준편차는 8인
정규분포에서 생산량을 랜덤하게 결정

2019-01-01부터 10일간 모든 공장(A,B)의 생산량을
날짜 별로 출력
````

````python
import numpy as np
import pandas as pd
from datetime import date, timedelta
from dateutil.parser import parse

start_ day = parse("2019-01-01")
factory_a = pd.Series([int(x) for x in np.random.normal(50,5,(10,))],
			index=[start_day + timedelta(days=x) for x in range(10)])
````





