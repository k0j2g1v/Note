# Android Studio

#### Android Component ( 4가지 component )
- Activity
- Service
- Broadcast Receiver
- content Provider
#### Android Framework의 동작방식

### Android
- Google이 중심이 되서 개발이 진행중인 휴대 단말기용 플랫폼
- 운영체제 ( OS - C언어 ) + 미들웨어( C, C++ ) + Android Framework( C, Java )
  
   +기본 Aplication( 주소록, 전화 )으로 구성된 Software Stack



